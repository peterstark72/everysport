from .everysport import Everysport
from .everysport import EverysportException


ALLSVENSKAN = 115183

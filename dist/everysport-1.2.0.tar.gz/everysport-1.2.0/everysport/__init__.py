#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''A Python wrapper for the Everysport API
'''

from everysport import Everysport
from everysport import EverysportException



'''
    Leagues
'''
#Football
ALLSVENSKAN = 57973
SUPERETTAN = 57974

#Hockey
SWISS_LEAGUE = 58882
SHL = 60243
NHL = 58878





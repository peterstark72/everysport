#!/usr/bin/env python
# -*- coding: utf-8 -*-

class League(object):

    def __init__(self, league_id):
        pass


    def load(self):
        pass
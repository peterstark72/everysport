#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''Results domain objects

ResultsIterator iterates over a lista of TeamResult tuples
TeamResult is a tuple with (team, stats and results), 
where results is a lista of Reslut tuples, team is a Team tuple and stats i Stats.
A Result is a tuple with (pos, events)

'''

from collections import namedtuple 

Result = namedtuple('Result', "pos, events")


def get_results_for_team(api_client, league_id, team_id):

    #Get current standings
    standings = api_client.league(league_id).standings()

    #Find out rounds
    number_of_rounds = max([team.gp for team in standings.teamstats()])

    #Get standings for each round
    standings_for_round = [api_client.standings(league_id).round(r).load() for r in range(1,number_of_rounds+1)]


    #Get all events for this team
    team_events = filter(lambda e:team_id in (e.home_team.id,e.visiting_team.id), api_client.events(league_id).finished() )


    for r in reversed(range(number_of_rounds)): #Make the last, the first
        pos = standings_for_round[r].get_teamposition(team_id)
        events = filter(lambda e:r==e.round, team_events) 
        yield Result(pos, events)

    



















